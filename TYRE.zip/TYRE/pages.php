<html>
	<head>
		<title>Malala Yousafzai</title>
		<link rel="stylesheet" href="style.css">
	</head>

<body>
<!--This is Top bar-->
<div id="top"><p>Top bar</p></div>
<!--this is header area-->
<div><?php include("include/header.php");?></div>
<!--This is navigation area-->
<div><?php include("include/navigation.php");?></div>
<!--This is sidebar-->

<div class="side">
<div><?php include("include/sidebar.php");?></div>

<div class="post_body">
<?php 
include("include/connect.php");
$page_id=$_GET['id'];

	$query="select * from posts where post_id='$page_id'";
	
	$run=mysql_query($query);
	while($row=mysql_fetch_array($run)){
	$title=$row['post_title'];
	$date=$row['post_date'];
	$author=$row['post_author'];
	$image=$row['post_image'];
	$content=$row['post_content'];

?>
<h2>
  <?php echo $title; ?>
</h2>
<p>Published on:&nbsp;&nbsp;<b><?php echo $date; ?></b></p>
<p align="right">Posted By:&nbsp;&nbsp;<b><?php echo $author; ?></b></p>
<center><img src="images/<?php echo $image; ?>" width="600"></center>
<p align="justify">
<?php echo $content; ?>
</p>
<?php } ?>
</div>
</div>
<!--this is footer -->
<div class="foot">This is footer</div>
</body>
</html>
