<html>
	<head>
		<title>Admin Panal</title>
		<link rel="stylesheet" href="admin_style.css">
	</head>
<body>
<header>
<h1><a href="index.php">Welcome to Admin Panel of Malala.com</a></h1>
</header>
<aside><h1>Manage Content</h1>
<h3><a href="logout.php">Admin Logout</a></h3>
<h3><a href="index.php?view=view">View Posts</a></h3>
<h3><a href="insert_post.php">Insert New Posts</a></h3>
</aside>
<center><h1> This is your Admin Panel</h1>
<p>you can manage all of your website content here</p>
</center>
<?php if(isset($_GET['view'])){?>
<table width="800" align="center" border="3">
	<tr>
		<td align="center" colspan="9" bgcolor="#FFA500"><h1>View All Posts</h1></td>
	</tr>
	
	<tr>
		<th>Post no</th>
		<th>Post Title</th>
		<th>Post Date</th>
		<th>Post Author</th>
		<th>Post Image</th>
		<th>Post Content</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
<?php

include("include/connect.php");

	if(isset($_GET['view'])){
	
	$query="select *from posts order by 1 DESC";
	$run=mysql_query($query);
	while($row=mysql_fetch_array($run)){
	
	$i=1;
	$id=$row['post_id'];
	$title=$row['post_title'];
	$date=$row['post_date'];
	$author=$row['post_author'];
	$image=$row['post_image'];
	$content=substr($row['post_content'],0,50);
?>
	
	<tr align="center">
		<td><?php echo $i++;?></td>
		<td><?php echo $title;?></td>
		<td><?php echo $date;?></td>
		<td><?php echo $author;?></td>
		<td><img src="../images/<?php echo $image;?>" width="100" height="100"></td>
		<td><?php echo $content;?></td>	
		<td><a href="edit.php?edit=<?php echo $id;?>">Edit</a></td>
		<td><a href="delete.php">Delete</a></td>
	</tr>
<?php }} }?>
</table>
</body>
</html>

