<!--This is header area-->
<div id="header">
<img style="float:left;" src="images/logo.jpg" height="100" width="250">
<img style="float:right;" src="images/banner.jpg" height="100" width="650">
</div>