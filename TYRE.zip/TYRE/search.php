<html>
	<head>
		<title>Malala Yousafzai</title>
		<link rel="stylesheet" href="style.css">
	</head>

<body>
<!--This is Top bar-->
<div id="top"><p>Top bar</p></div>
<!--this is header area-->
<div><?php include("include/header.php");?></div>
<!--This is navigation area-->
<div><?php include("include/navigation.php");?></div>
<!--This is sidebar-->

<div class="side">
<div><?php include("include/sidebar.php");?></div>
<!--This is post content area-->
<div class="post_body">
<?php
include("include/connect.php");

	if(isset($_GET['submit'])) 
	{
		$search_id=$_GET['search'];
		
	$query="select * from posts where post_title like '%$search_id%' ";
	
	$run=mysql_query($query);
	
	while($row=mysql_fetch_array($run)){
		$post_id=$row['post_id'];
		$post_title=$row['post_title'];
		$post_image=$row['post_image'];
		$post_content=substr($row['post_content'],0,100);
	
	}
?> 
<h2>
<a href="pages.php?id=<?php echo $post_id;?>">
<?php echo $post_title; ?>
</a>
</h2>
 
<center><img src="images/<?php echo $post_image; ?>" width="150" height="150"></center>
<p align="justify">
<?php echo $post_content; ?>
</p>
<p align="right"><a href="pages.php?id=<?php echo $post_id;?>">Read More</a></p>
<?php } ?>
</div>
</div>
<!--this is footer -->
<div class="foot">This is footer</div>
</body>
</html>
