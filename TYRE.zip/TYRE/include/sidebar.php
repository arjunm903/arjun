<div id="sidebar"> 

<!---------Email subscribe------>
<h2>Subscribe via Email</h2>
<form style="padding:3px;" action="http://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('http://feedburner.google.com/fb/a/mailverify?uri=OnlineComputerTeacherKarachi','popuwindow','scrollbars=yes,width=550,height=520');return true"><p>Enter your email address:</p><p><input type="text" style="width:140px" name="email"/></p><input type="hidden" value="OnlineComputerTeacherKarachi" name="uri"/> <input type="hidden" name="loc" value="en_US"/><input type="submit" value="subscribe"/></form>

<!--social bottons---->
<div class="social">
 	<h2>Follow Us </h2>
	<a href="http://www.facebook.com/onlineustaadwali" target="blank"><img src="images/facebook.jpg"></a>
	<a href="http://www.pinterest.com/abdulwali" target="blank"><img src="images/pinterest.jpg"></a>
	<a href="http://www.twitter.com/abdulwali" target="blank"><img src="images/twitter.jpg"></a>
	<a href="http://www.google.com/abdulwali" target="blank"><img src="images/google.jpg"></a>
</div>
<h2> Recent Posts</h2>
<?php 
include("include/connect.php");
$query="select *from posts order by 1 DESC LIMIT 0,5";
$run=mysql_query($query);
while($row=mysql_fetch_array($run)){
	$post_id=$row['post_id'];
	$title=$row['post_title'];
	$image=$row['post_image'];
?>

<center>
<a href="pages.php?id=<?php echo $post_id;?>"><img src="images/<?php echo $image;?>" width="150" height="150" /></a><a href="pages.php?id=<?php echo $post_id;?>">
<h3><?php echo $title; ?></h3></a></center>
<?php }?>
</div>