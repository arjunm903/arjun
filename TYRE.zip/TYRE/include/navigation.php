<div class="navbar">
	<div id="menu">
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="#">About Us</a></li>
			 <li><a href="#"><div id="sub">Product</a>
			 
				<ul>
				   <li><a href="#">JK Tyre</a></li>
				   <li><a href="#">Ralco Tyre</a></li>
				   <li><a href="#">MRF Tyre</a></li>
				</ul>  
				</div>      
			 </li>

			<!---<li><a href="#">Product</a></li> -->
			<li><a href="#">Services</a></li>
			<li><a href="#">Gallary</a></li>
			<li><a href="#">Contact Us</a></li>
		</ul>
	</div>
	<div class="searchbox">
		<form action="search.php" method="get">
			<input type="text" size="25" name="search" placeholder="Search this site">
			<input type="submit" name="submit" value="search"></form>
	</div>
</div>	