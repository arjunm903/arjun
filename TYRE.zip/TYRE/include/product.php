<div class="body">
<div> <!--<?php include("include/post_body.php");?>---></div>
</div>

<div class="body1">
<div> <!--<?php include("include/post_body.php");?>---></div>
</div>

<div class="body2">
<div> <!--<?php include("include/post_body.php");?>---></div>
</div>






