<!--This is header area-->
<div id="header">
<img style="float:left;" src="images/logo.jpg" height="140" width="250">
<img style="float:right;" src="images/banner1.jpg" height="140" width="620"></div>
